// Helper function
var translate = function(x, y) {return 'translate('+x+','+y+')';}
