// d3.select('svg')
// 	.append('line')
// 	.attr({x0: 10, y0: 10, x1: 50, y1: 50});

s = d3.selectAll('div');
// d = ['red', 'yellow', 'green', 'blue', 'pink'];
// d = [{x: 0, y: 10}, {x: 10, y: 40}, {x: 20, y: 30}, {x: 30, y: 10}, {x: 40, y: 80}];
// d = [{i: 0, value: 10}, {i: 10, value: 40}, {i: 20, value: 30}, {i: 30, value: 10}, {i: 40, value: 80}];
d = [1, 2, 3, 4, 5];

s.data(d);


update = function(data) {
  // make selection
  s = d3.selectAll('div');

  // join data
  u = s.data(data);

  // append new DOM elements
  u.enter().append('div');

  // update DOM elements
  u.text( function(d) {return d;} );

  // remove old elements
  u.exit().remove();
}


// s.style('background-color', 'steelblue');
// s.style('height', '10px');
// s.style('width', function(d) {return d.value + 'px';});