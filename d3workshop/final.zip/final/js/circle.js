// Configuration
var r = 50, padding = 10, cols = 5;

// The data
var d = [];

// Create group for the chart
var g = d3.select('svg')
  .append('g')
  .attr('transform', 'translate(100,100)');

// Function to initialise data
function initData() {
  d = [];
  for(var i=0; i<20; i++)
    d.push(Math.random() * 100);
}

// Scales
var colScale = d3.scale.linear().domain([0, 100]).range(['white', 'steelblue']);
var rScale = d3.scale.linear().domain([0, 100]).range([0, r]);


// Update function
function update(data) {

  // Selection
  var s = d3.select('g').selectAll('circle');

  // Data-join (returns an 'update selection')
  var u = s.data(data);

  // Handle entering and exiting elements
  u.enter().append('circle').style('fill', 'white');
  u.exit().remove();

  // And finally, the update
  u.attr('cx', function(d, i) {return (i%cols) * (r+padding) * 2;})
    .attr('cy', function(d, i) {return Math.floor(i/cols) * (r+padding) * 2;})
    .transition()
    .duration(1000)
    .attr('r', function(d) {return rScale(d);})
    .style('fill', function(d) {return colScale(d);});
}

initData();
update(d);