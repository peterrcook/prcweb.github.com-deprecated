var width = 1200,
    height = 800;

var translate = function(x, y) {return 'translate('+x+','+y+')';}
var toId = function(s) {return s.replace(/[\., ]/g, '');}

d3.json('data/tree.json', function(error, root) {
  var svg = d3.select('body').append('svg')
    .append('g')
    .attr('transform', 'translate(80,0)');

  // Tree layout
  var tree = d3.layout.tree()
      .size([height, width - 160]);
  var nodes = tree.nodes(root),
      links = tree.links(nodes);

  // Links (also check out d3.svg.diagonal)
  // Note we swap x and y to reduce label overlap
  var link = svg.selectAll('.link')
    .data(links)
    .enter()
    .append('line')
    .classed('link', true)
    .attr('x1', function(d) {return d.source.y;})
    .attr('y1', function(d) {return d.source.x;})
    .attr('x2', function(d) {return d.target.y;})
    .attr('y2', function(d) {return d.target.x;});

  var node = svg.selectAll('.node')
    .data(nodes)
    .enter()
    .append('g')
    .classed('node', true)
    .attr('id', function(d) {return toId(d.name);})
    .attr('transform', function(d) {return translate(d.y, d.x);});

  node.append('circle')
      .attr('r', 4);

  node.append('text')
      .attr('dx', -7)
      .attr('dy', 4)
      .style('text-anchor', 'end')
      .text(function(d) { return d.name; });

  node.on('mouseover', function(d) {
    if(d.children === undefined) return;

    d3.select(this)
      .classed('selected', true);
      
    for(var i=0; i<d.children.length; i++) {
      d3.select('#'+toId(d.children[i].name))
        .classed('selected', true);
    }
  });

  node.on('mouseout', function(d) {
    d3.selectAll('.node')
      .classed('selected', false);
  });
});
