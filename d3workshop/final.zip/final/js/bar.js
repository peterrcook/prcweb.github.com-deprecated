function update(d) {
  var s = d3.select('#chart').selectAll('div');

  var u = s.data(d);

  u.enter().append('div');
  u.exit().remove();

  u//.text(function(d) {return d;})
    .style('width', function(d) {return d * 40 + 'px';})
    .style('margin-bottom', '1px')
    .style('margin-left', '40px')
    .style('background-color', 'darkseagreen');
}

var data = [4, 2, 3, 4, 6];
update(data);
