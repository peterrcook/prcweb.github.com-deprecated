function update(d) {
  var s = d3.select('#chart').selectAll('div');

  var u = s.data(d);

  u.enter().append('div');
  u.exit().remove();

  u.text(function(d) {return d;})
    .style('width', function(d) {return d * 100 + 'px';})
    .style('background-color', 'darkseagreen');
}

update([4, 2, 3, 4, 6]);
