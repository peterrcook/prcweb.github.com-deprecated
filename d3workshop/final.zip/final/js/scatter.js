var width = 800, height = 600;
var xScale, yScale;

// Helper function
var translate = function(x, y) {return 'translate('+x+','+y+')';}

var g = d3.select('#chart')
  .append('svg')
  .append('g')
  .attr('transform', translate(70, 30));

d3.json('data/players.json', function(err, json) {
  update(json);
  addAxes();
});


function update(data) {
  // Update scales
  xScale = d3.scale.log().domain( d3.extent(data, function(d) {return d.points;}) ).range([0, width]);
  yScale = d3.scale.linear().domain( d3.extent(data, function(d) {return d.gamesWon;}) ).range([height, 0]);

  // Selection
  var s = g.selectAll('circle');

  // Join
  var u = s.data(data);

  // Enter/exit
  u.enter().append('circle');
  u.exit().remove();

  // Update
  u.attr('cx', function(d) {return xScale(d.points);})
    .attr('cy', function(d) {return yScale(d.gamesWon);})
    .attr('r', 4);

  // Events
  u.on('mouseover', function(d) {
      d3.select('#info')
        .text(d.name);
  });
}

function addAxes() {
  // x-axis
  var xAxis = d3.svg.axis().scale(xScale).orient( 'bottom' );
  g.append('g')
    .classed('axis x', true)
    .attr('transform', translate(0, height + 10))
    .call(xAxis);

  // x-axis label
  g.select('.x.axis')
    .append('text')
    .attr({'x' : 0.5 * width, 'y': 40, 'text-anchor': 'middle'})
    .text('ATP Points');

  // y-axis
  var yAxis = d3.svg.axis().scale(yScale).orient( 'left' );
  g.append('g')
    .classed('axis y', true)
    .attr('transform', translate(-10, 0))
    .call(yAxis);

  // y-axis label
  g.select('.y.axis')
    .append('text')
    .attr({'transform': translate(-40, 0.5*height)+'rotate(-90)', 'text-anchor': 'middle'})
    .text('Games Won');

}
