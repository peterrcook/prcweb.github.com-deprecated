var width = 800, height = 600;
var xScale, yScale;

// Helper function
var translate = function(x, y) {return 'translate('+x+','+y+')';}

var g = d3.select('#chart')
  .append('svg')
  .append('g')
  .attr('transform', translate(70, 30));


function update(data) {
  // Update scales
  xScale = d3.scale.log().domain( d3.extent(data, function(d) {return d.points;}) ).range([0, width]);
  yScale = d3.scale.linear().domain( d3.extent(data, function(d) {return d.gamesWon;}) ).range([height, 0]);

  // Selection
  var s = g.selectAll('circle');

  // Join
  var u = s.data(data);

  // Enter/exit
  u.enter().append('circle');
  u.exit().remove();

  // Update
  // WORKSHOP TODO

  // Events
  // WORKSHOP TODO
}

function addAxes() {
  // x-axis

  // x-axis label

  // y-axis

  // y-axis label

}


// (Data has already been loaded by data/players.js)
update(data);
addAxes();
