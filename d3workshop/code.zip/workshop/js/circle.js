// Configuration
var r = 50, padding = 10, cols = 5;

// The data
var d = null;

// Create group for the chart
var g = d3.select('svg')
  .append('g')
  .attr('transform', 'translate(100,100)');

// Function to initialise data
function initData() {
  d = [];
  for(var i=0; i<20; i++)
    d.push(Math.random() * 100);
}

// Scales
// var colScale = TODO
// var rScale = TODO


// Update function
function update(data) {

  // Selection

  // Data-join (returns an 'update selection')

  // Handle entering and exiting elements

  // And finally, the update

}

initData();
update(d);