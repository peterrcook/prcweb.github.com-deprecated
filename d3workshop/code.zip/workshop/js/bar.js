function update(data) {
  
  // Selection


  // Data-join


  // Enter & exit


  // Update

}

var values = [4, 2, 3, 4, 6];
update(values);
