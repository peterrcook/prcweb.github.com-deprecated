var width = 1200,
    height = 800;

var translate = function(x, y) {return 'translate('+x+','+y+')';}
var toId = function(s) {return s.replace(/[\., ]/g, '');}

var svg = d3.select('body').append('svg')
  .append('g')
  .attr('transform', 'translate(80,0)');

// Tree layout

// Append links (also check out d3.svg.diagonal)

// Append nodes
