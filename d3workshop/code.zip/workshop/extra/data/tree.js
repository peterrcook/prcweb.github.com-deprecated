var data = {
  "name": "Federer R.",
  "children": [
    {
      "name": "Murray A.",
      "children": [
        {
          "name": "Tsonga J.W.",
          "children": [
            {
              "name": "Kohlschreiber P.",
              "children": [
                {
                  "name": "Baker B.",
                  "children": [
                    {
                      "name": "Paire B.",
                      "children": [
                        {
                          "name": "Dolgopolov O.",
                          "children": [
                            {
                              "name": "Bogomolov A."
                            }
                          ]
                        },
                        {
                          "name": "Ebden M."
                        }
                      ]
                    },
                    {
                      "name": "Nieminen J.",
                      "children": [
                        {
                          "name": "Lopez F."
                        }
                      ]
                    },
                    {
                      "name": "Machado R."
                    }
                  ]
                },
                {
                  "name": "Rosol L.",
                  "children": [
                    {
                      "name": "Nadal R.",
                      "children": [
                        {
                          "name": "Bellucci T."
                        }
                      ]
                    },
                    {
                      "name": "Dodig I."
                    }
                  ]
                },
                {
                  "name": "Jaziri M.",
                  "children": [
                    {
                      "name": "Zopp J."
                    }
                  ]
                },
                {
                  "name": "Haas T."
                }
              ]
            },
            {
              "name": "Fish M.",
              "children": [
                {
                  "name": "Goffin D.",
                  "children": [
                    {
                      "name": "Levine J.",
                      "children": [
                        {
                          "name": "Beck K."
                        }
                      ]
                    },
                    {
                      "name": "Tomic B."
                    }
                  ]
                },
                {
                  "name": "Ward J.",
                  "children": [
                    {
                      "name": "Andujar P."
                    }
                  ]
                },
                {
                  "name": "Ramirez-Hidalgo R."
                }
              ]
            },
            {
              "name": "Lacko L.",
              "children": [
                {
                  "name": "Melzer J.",
                  "children": [
                    {
                      "name": "Wawrinka S."
                    }
                  ]
                },
                {
                  "name": "Ungur A."
                }
              ]
            },
            {
              "name": "Garcia-Lopez G.",
              "children": [
                {
                  "name": "Roger-Vasselin E."
                }
              ]
            },
            {
              "name": "Hewitt L."
            }
          ]
        },
        {
          "name": "Ferrer D.",
          "children": [
            {
              "name": "Del Potro J.M.",
              "children": [
                {
                  "name": "Nishikori K.",
                  "children": [
                    {
                      "name": "Serra F.",
                      "children": [
                        {
                          "name": "Kuznetsov An."
                        }
                      ]
                    },
                    {
                      "name": "Kukushkin M."
                    }
                  ]
                },
                {
                  "name": "Soeda G.",
                  "children": [
                    {
                      "name": "Kunitsyn I."
                    }
                  ]
                },
                {
                  "name": "Haase R."
                }
              ]
            },
            {
              "name": "Roddick A.",
              "children": [
                {
                  "name": "Phau B.",
                  "children": [
                    {
                      "name": "Odesnik W."
                    }
                  ]
                },
                {
                  "name": "Baker J."
                }
              ]
            },
            {
              "name": "De Schepper K.",
              "children": [
                {
                  "name": "Bachinger M."
                }
              ]
            },
            {
              "name": "Brown D."
            }
          ]
        },
        {
          "name": "Cilic M.",
          "children": [
            {
              "name": "Querrey S.",
              "children": [
                {
                  "name": "Raonic M.",
                  "children": [
                    {
                      "name": "Giraldo S."
                    }
                  ]
                },
                {
                  "name": "Pospisil V."
                }
              ]
            },
            {
              "name": "Kubot L.",
              "children": [
                {
                  "name": "Ito T."
                }
              ]
            },
            {
              "name": "Stebe C.M."
            }
          ]
        },
        {
          "name": "Baghdatis M.",
          "children": [
            {
              "name": "Dimitrov G.",
              "children": [
                {
                  "name": "Anderson K."
                }
              ]
            },
            {
              "name": "Montanes A."
            }
          ]
        },
        {
          "name": "Karlovic I.",
          "children": [
            {
              "name": "Sela D."
            }
          ]
        },
        {
          "name": "Davydenko N."
        }
      ]
    },
    {
      "name": "Djokovic N.",
      "children": [
        {
          "name": "Mayer F.",
          "children": [
            {
              "name": "Gasquet R.",
              "children": [
                {
                  "name": "Almagro N.",
                  "children": [
                    {
                      "name": "Rufin G.",
                      "children": [
                        {
                          "name": "Darcis S."
                        }
                      ]
                    },
                    {
                      "name": "Rochus O."
                    }
                  ]
                },
                {
                  "name": "Bemelmans R.",
                  "children": [
                    {
                      "name": "Berlocq C."
                    }
                  ]
                },
                {
                  "name": "Kamke T."
                }
              ]
            },
            {
              "name": "Janowicz J.",
              "children": [
                {
                  "name": "Gulbis E.",
                  "children": [
                    {
                      "name": "Berdych T."
                    }
                  ]
                },
                {
                  "name": "Bolelli S."
                }
              ]
            },
            {
              "name": "Petzschner P.",
              "children": [
                {
                  "name": "Kavcic B."
                }
              ]
            },
            {
              "name": "Tursunov D."
            }
          ]
        },
        {
          "name": "Troicki V.",
          "children": [
            {
              "name": "Monaco J.",
              "children": [
                {
                  "name": "Chardy J.",
                  "children": [
                    {
                      "name": "Volandri F."
                    }
                  ]
                },
                {
                  "name": "Mayer L."
                }
              ]
            },
            {
              "name": "Klizan M.",
              "children": [
                {
                  "name": "Chela J.I."
                }
              ]
            },
            {
              "name": "Granollers M."
            }
          ]
        },
        {
          "name": "Stepanek R.",
          "children": [
            {
              "name": "Becker B.",
              "children": [
                {
                  "name": "Blake J."
                }
              ]
            },
            {
              "name": "Stakhovsky S."
            }
          ]
        },
        {
          "name": "Harrison R.",
          "children": [
            {
              "name": "Lu Y.H."
            }
          ]
        },
        {
          "name": "Ferrero J.C."
        }
      ]
    },
    {
      "name": "Youzhny M.",
      "children": [
        {
          "name": "Istomin D.",
          "children": [
            {
              "name": "Falla A.",
              "children": [
                {
                  "name": "Mahut N.",
                  "children": [
                    {
                      "name": "Lorenzi P."
                    }
                  ]
                },
                {
                  "name": "Isner J."
                }
              ]
            },
            {
              "name": "Andreev I.",
              "children": [
                {
                  "name": "Golding O."
                }
              ]
            },
            {
              "name": "Seppi A."
            }
          ]
        },
        {
          "name": "Tipsarevic J.",
          "children": [
            {
              "name": "Sweeting R.",
              "children": [
                {
                  "name": "Starace P."
                }
              ]
            },
            {
              "name": "Nalbandian D."
            }
          ]
        },
        {
          "name": "Cervantes I.",
          "children": [
            {
              "name": "Cipolla F."
            }
          ]
        },
        {
          "name": "Young D."
        }
      ]
    },
    {
      "name": "Malisse X.",
      "children": [
        {
          "name": "Verdasco F.",
          "children": [
            {
              "name": "Zemlja G.",
              "children": [
                {
                  "name": "Goodall J."
                }
              ]
            },
            {
              "name": "Wang J."
            }
          ]
        },
        {
          "name": "Simon G.",
          "children": [
            {
              "name": "Mathieu P.H."
            }
          ]
        },
        {
          "name": "Matosevic M."
        }
      ]
    },
    {
      "name": "Benneteau J.",
      "children": [
        {
          "name": "Russell M.",
          "children": [
            {
              "name": "Menendez-Maceiras A."
            }
          ]
        },
        {
          "name": "Muller G."
        }
      ]
    },
    {
      "name": "Fognini F.",
      "children": [
        {
          "name": "Llodra M."
        }
      ]
    },
    {
      "name": "Ramos A."
    }
  ]
};