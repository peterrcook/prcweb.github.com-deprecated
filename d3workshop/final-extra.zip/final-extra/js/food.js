var width = 20, padding = 2, margin = 100;

// Helper function
var translate = function(x, y) {return 'translate('+x+','+y+')';}

// Colour scale
// 1800kCal is minimum recommended
// ~2250kCal is recommended
var fillScale = d3.scale.linear()
  .domain([1800, 2250, 4000])
  .range(['white', 'green', 'red']);

// Load data and make chart
d3.text('data/food.csv', function(err, data) {

  // Convert csv to array of arrays
  data = d3.csv.parseRows(data);

  var svg = d3.select('svg');

  // For each country, append g element and translate downwards
  var updateG = svg.selectAll('g').data(data);
  updateG.enter().append('g');
  updateG
    .attr('transform', function(d, i) {return translate(0, i * (width + padding));});

  // For each year, append rect element and translate across
  var updateR = updateG.selectAll('rect').data(function(d) {return d.slice(1);});
  updateR.enter().append('rect');
  updateR
    .attr('x', function(d, i) {return margin + i * (width + padding);})
    .attr('width', width)
    .attr('height', width)
    .attr('rx', 2)
    .attr('fill', function(d) {return fillScale(d)});

  // Create country labels
  updateG.append('text')
    .attr('y', width - 5)
    .attr('x', margin - 5)
    .attr('text-anchor', 'end')
    .text(function(d) {return d[0];});
});