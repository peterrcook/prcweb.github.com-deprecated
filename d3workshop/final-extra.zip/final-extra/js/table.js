d3.text('data/table.csv', function(err, data) {

  data = d3.csv.parseRows(data);

  var t = d3.select('#wrapper')
    .append('table');

  /* Select table rows (will be an empty selection to begin with) */
  var rowSelection = t.selectAll('tr');

  /* Join the elements of the outer array (i.e. the inner arrays) to tr elements */
  var rowUpdate = rowSelection.data(data);

  /* Handle entering tr elements */
  rowUpdate.enter().append('tr');


  /* On each row, select table td elements (will be an empty selection to begin with) */
  var colSelection = rowUpdate.selectAll('td');

  /* On each row, join the elements of the inner arrays to td elements */
  var colUpdate = colSelection.data(function(d) {return d;});

  /* Handle entering td elements */
  colUpdate.enter().append('td');
  colUpdate.text(function(d) {return d;})
    .style('color', function(d) {return d > 3500 ? 'red' : 'black';});

});